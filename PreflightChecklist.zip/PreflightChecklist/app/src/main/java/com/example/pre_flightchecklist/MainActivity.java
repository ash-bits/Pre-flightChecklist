package com.example.pre_flightchecklist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    ToggleButton simpleTB;
    RadioGroup radioGroup1;
    RadioButton  radioNegative, radioYes;
    ImageButton imgPlane;
    TextView txtSwab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);

        radioNegative =findViewById (R.id.radioNegative);
        radioYes =findViewById (R.id.radioYes);
        radioGroup1 =findViewById (R.id.radioGroup1);
        simpleTB =findViewById (R.id.simpleTB);
        imgPlane =findViewById (R.id.imgPlane);
        txtSwab =findViewById (R.id.textView);

        simpleTB.setOnCheckedChangeListener ((buttonView, isChecked) -> {
            if(simpleTB.isChecked ()){
                txtSwab.setText ("");
                radioGroup1.setVisibility (View.INVISIBLE);
            }else{
                txtSwab.setText ("Swab Test");
                radioGroup1.setVisibility (View.VISIBLE);
            }
        });

        imgPlane.setOnClickListener (v -> {
            if (radioNegative.isChecked () && radioYes.isChecked ()){
                Toast.makeText (getApplicationContext (), "Welcome onBoard!", Toast.LENGTH_SHORT).show ();
            }else if (simpleTB.isChecked () && radioYes.isChecked ()){
                Toast.makeText (getApplicationContext (), "Welcome onBoard!", Toast.LENGTH_SHORT).show ();
            }else {
                Toast.makeText (getApplicationContext (), "Comply Requirements", Toast.LENGTH_SHORT).show ();
            }
        });
    }
}